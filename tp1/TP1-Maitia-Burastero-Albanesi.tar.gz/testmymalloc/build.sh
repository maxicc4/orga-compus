gcc ../mymalloc.S testmymalloc.c -ggdb -o testmymalloc
 
