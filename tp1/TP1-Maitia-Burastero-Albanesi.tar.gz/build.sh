gcc -Wall -ggdb buffers.S mymalloc.S palindromes.S is_palindrome.S charIsValid.S main.c -o tp1

 
