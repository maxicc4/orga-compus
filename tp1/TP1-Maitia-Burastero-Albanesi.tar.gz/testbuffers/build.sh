gcc testbuf.* ../buffers.S ../mymalloc.S -o testbuf -ggdb

 
